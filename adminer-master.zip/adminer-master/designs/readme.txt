Copy adminer.css alongside Adminer PHP script to use an alternative design.
