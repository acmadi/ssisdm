../adminer/plugin.php - demo usage
http://www.adminer.org/plugins/ - documentation
